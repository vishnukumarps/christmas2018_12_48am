﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudyKendo.Models
{
    public class Student
    {
        public  string  InternalStudentId { get; set; }
        public int RollNo { get; set; }
        public string Name { get; set; }
        public DateTime Dob { get; set; }
        public string Dob2 { get; set; }

        public int M1 { get; set; }
        public long  logTime { get; set; }
    }
}
