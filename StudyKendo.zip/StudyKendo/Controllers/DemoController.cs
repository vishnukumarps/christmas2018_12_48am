﻿using Grand.Framework.Kendoui;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudyKendo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudyKendo.Controllers
{
    public class DemoController: Controller
    {
       
        public async Task<IActionResult> Index()
        {
            await Task.FromResult(0);
            return View();
        }
        public async Task<IActionResult> List()
        {
            await Task.FromResult(0);
           
            return View();
        }
        public async Task<IActionResult> List2()
        {
            await Task.FromResult(0);

            return View();
        }


        public async Task<IActionResult> List3()
        {
            await Task.FromResult(0);
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> ReadData()
        {
            await Task.FromResult(0);
            List<Student> students = new List<Student>();
            students.Add(new Student
            {
                InternalStudentId = Guid.NewGuid().ToString(),
                Name = "Vishnu",
                Dob = DateTime.Now,
                Dob2 = "08-10-1994",
                M1 = 43
            });
            students.Add(new Student
            {
                InternalStudentId = Guid.NewGuid().ToString(),
                Name = "Bala Krishnan",
                Dob = DateTime.Now,
                Dob2 = "22-6-1995",
                M1 = 43
            });
           var jsn = JsonConvert.SerializeObject(students);
           var gridModel = new DataSourceResult {Data=students };
            return Json(gridModel);
        }


        
        [HttpPost]
      /*  [ValidateAntiForgeryToken]*/
        public async Task<JsonResult> ReadData2()
        {
            await Task.FromResult(0);
            List<Student> students = new List<Student>();
            students.Add(new Student
            {
                InternalStudentId = Guid.NewGuid().ToString(),
                Name = "Vishnu",
                Dob = DateTime.Now,
                Dob2 = "08-10-1994",
                M1 = 43
            });
            students.Add(new Student
            {
                InternalStudentId = Guid.NewGuid().ToString(),
                Name = "Bala Krishnan",
                Dob = DateTime.Now,
                Dob2 = "22-6-1995",
                M1 = 43
            });
            var jsn = JsonConvert.SerializeObject(students.First());
           
            return Json(jsn);
        }


    }
}
